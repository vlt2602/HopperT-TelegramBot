import asyncio
from telegram_handler import start_telegram_bot

if __name__ == "__main__":
    asyncio.run(start_telegram_bot())
